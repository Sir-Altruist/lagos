import React from "react";
import BasicTable from "../Component/table/BasicTable";

const Admin2 = () => {
  return (
    <div className="admin">
      <BasicTable />
    </div>
  );
};

export default Admin2;

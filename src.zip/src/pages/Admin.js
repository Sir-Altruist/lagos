import React, { useState, useEffect } from 'react';
import { 
    Box,
    Container, 
    Table, 
    TableBody, 
    TableContainer, 
    TableHead, 
    TableRow, 
    Paper, 
    Button, 
    TextField,
    InputAdornment
} from '@mui/material'
import LoopIcon from '@mui/icons-material/Loop';
// import { data } from '../Component/data'
import { styled } from '@mui/material/styles';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import axios from 'axios';
import moment from 'moment'



const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));


const Admin = () => {
    
    const [items, setItems] = useState([])
    //search query
    const [q, setQ] = useState('')
    //loading
    const [loading, setLoading] = useState(false)

 
    //Search parameters
    const [searchParams] = useState(['name', 'invoice'])



    useEffect(() => {
      const getData = async() => {
        try {
           const response = await axios.get("http://localhost:8000/portals/")
          
           const {data} = response
           setItems(data)

           console.log(data)
        }
        catch(error){
             console.log(error)
        }
      }
        getData()
      // setItems(data)
    }, [])

  //   const handleSearch = items => {
  //     return items.filter(item => {
  //         return searchParams.some(newItem => {
  //           console.log(typeof item[newItem])
  //             return (
  //                 item[newItem]
  //                     // .toString()
  //                     .toLowerCase()
  //                     .indexOf(q.toLowerCase()) > - 1
  //             )
  //         })
  //     })
  // }

  // const search = items.filter(item => {
  //   if(q === ''){
  //     return item
  //   } else if (item.toLowerCase().includes(q)) {
  //     return item;

  //   }
  // })
  

  const pinNumber = async (id) => {
    try {
      setLoading(true)
      const data = {
        id : id
      }
    const response = await axios.post("http://localhost:8000/portals/savePin/" , data)
    console.log(response.data)
    window.location.reload()
    setLoading(false)
  
    }
    catch(error) {
        console.log(error)
    }
 
  }
 
    

  return (
  <Box component='div'>
      <Container style={{ marginTop: '10rem'}}>
        <div style={{ margin: '0 auto'}}>
            <TextField 
            id="outlined-basic" 
            label="Search..." 
            variant="outlined" 
            size='small'
            InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <PersonSearchIcon color='primary' />
                  </InputAdornment>
                ),
              }} 
            onChange={(e) => setQ(e.target.value)}
            value={q} 
            />
        </div>

      <TableContainer component={Paper} style={{ marginTop: '5rem'}}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell style={{ textAlign: 'center'}}>Name</StyledTableCell>
            <StyledTableCell align="right" style={{ textAlign: 'center'}}>Invoice Number</StyledTableCell>
            <StyledTableCell align="right" style={{ textAlign: 'center'}}>Receipt Number</StyledTableCell>
            <StyledTableCell align="right" style={{ textAlign: 'center'}}>Date</StyledTableCell>
            <StyledTableCell align="right" style={{ textAlign: 'center'}}>PIN</StyledTableCell>
            <StyledTableCell align="right" style={{ textAlign: 'center'}}></StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {items
          .filter(item => {
            if(q === ''){
              return item
            } else if(item.Name.toLowerCase().includes(q.toLowerCase()) || item.trnsref.toLowerCase().includes(q.toLowerCase()) ) {
              return item
            } else {
              return null
            }
          })
          .map((single, i) => {
                return (
                    <StyledTableRow key={i}>
                    <StyledTableCell component="th" scope="row" style={{ textAlign: 'center'}}>
                    {single.Name}
                    </StyledTableCell>
                    <StyledTableCell align="right" style={{ textAlign: 'center'}}>{single.InvoiceNumber}</StyledTableCell>
                    <StyledTableCell align="right" style={{ textAlign: 'center'}}>{single.trnsref}</StyledTableCell>
                    <StyledTableCell align="right" style={{ textAlign: 'center'}}>{moment(single.created_at).format('DD/MM/YYYY')}</StyledTableCell>
                    <StyledTableCell align="right" style={{ textAlign: 'center'}}>{single.pinum}</StyledTableCell>
                    <StyledTableCell align="right" style={{ textAlign: 'center'}}>
                      {loading 
                      ? <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}><LoopIcon /></Button>
                      : <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}} onClick = {() => pinNumber(single.id)}>Generate pin</Button>
                      }
                    </StyledTableCell>
                  </StyledTableRow>
                )
            })}
        </TableBody>
      </Table>
    </TableContainer>
      </Container>
  </Box>
  );
};

export default Admin;

import { Button } from '@mui/material'

export const data = [
    {
        name: 'Akinrotimi Akindele',
        invoice: '12mn3',
        receipt: '09vnb',
        date: '12-03-22',
        pin: '',
        btn: <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}>Generate pin</Button>
    },
    {
        name: 'Esho Oluwasegun',
        invoice: '12mn3',
        receipt: '09vnb',
        date: '12-03-22',
        pin: '',
        btn: <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}>Generate pin</Button>
    },
    {
        name: 'Awosika Ibukun',
        invoice: '12mn3',
        receipt: '09vnb',
        date: '12-03-22',
        pin: '',
        btn: <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}>Generate pin</Button>
    },        
    {
        name: 'Ayeni Bukunmi',
        invoice: '13mn3',
        receipt: '08vnb',
        date: '12-03-22',
        pin: '',
        btn: <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}>Generate pin</Button>
    },
    {
        name: 'Aromodele Timileyin',
        invoice: '13mn3',
        receipt: '08vnb',
        date: '12-03-22',
        pin: '',
        btn: <Button variant='contained' color='primary' style={{ textTransform: 'inherit'}}>Generate pin</Button>
    }
]
